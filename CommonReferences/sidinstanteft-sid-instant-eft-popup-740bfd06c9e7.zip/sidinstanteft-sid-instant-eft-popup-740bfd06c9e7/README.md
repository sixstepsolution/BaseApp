# README #
* This repository is for merchants to download and use our popup function.
* They can either download the files directly or install it using bower.

### Files ###
* sidPopup.js
* sidPopupStyle.css

### Bower ###
Install using Bower

$ Bower install sid-instant-eft-popup --save